﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Signup : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        string query = "INSERT INTO [User](fname,lname,email,password,address,city,zip,state) Values(@fname,@lname,@email,@password,@address,@city,@zip,@state)";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string fName = inputFname.Text;
        string lName = inputLname.Text;
        string email = inputEmail.Text;
        string password = inputPassword.Text;
        string address = inputAddress.Text;
        string city = inputCity.Text;
        string zip = inputZip.Text;
        string state = inputState.SelectedValue;

        SqlConnection con = new SqlConnection(connectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand(query, con);
        cmd.Parameters.AddWithValue("@fname", fName);
        cmd.Parameters.AddWithValue("@lname",lName);
        cmd.Parameters.AddWithValue("@email",email);
        cmd.Parameters.AddWithValue("@password",password);
        cmd.Parameters.AddWithValue("@address",address);
        cmd.Parameters.AddWithValue("@city",city);
        cmd.Parameters.AddWithValue("@zip",zip);
        cmd.Parameters.AddWithValue("@state",state);

        int result = cmd.ExecuteNonQuery();

        if(result>0)
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Response.Write("<script>alert('Some Error Occured')</script>");
        }

        con.Close();
    }
  }
}
 