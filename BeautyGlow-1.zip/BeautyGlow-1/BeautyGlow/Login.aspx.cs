﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Login : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            String email = inputEmail.Text;
            String password = inputPassword.Text;
            String query = "SELECT * FROM [User] WHERE email=@email AND password=@password";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@password", password);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string id = dr["Id"].ToString();
                string fname = dr["fname"].ToString();
                string lname = dr["lname"].ToString();
                string address = dr["address"].ToString();
                string city = dr["city"].ToString();
                string zip = dr["zip"].ToString();
                string state = dr["state"].ToString();

                Session["id"] = id;
                Session["email"] = email;
                Session["fname"] = fname;
                Session["lname"] = lname;
                Session["address"] = address;
                Session["city"] = city;
                Session["zip"] = zip;
                Session["state"] = state;

                Response.Redirect("Home.aspx");
            }
            else
            {
                Response.Write("<script>alert('Incorrect Credentials')</script>");
            }
            con.Close();
        }
    }
}