﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class BuyHairProduct : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            string productId = Request.QueryString["id"];
            FetchProductDetails(productId);

            if (Session["fname"] != null && Session["lname"] != null && Session["email"] != null &&
                Session["address"] != null && Session["city"] != null && Session["zip"] != null && Session["state"] != null)
            {

                uname.Text = "Name: " + Session["fname"].ToString() + " " + Session["lname"].ToString();
                Email.Text = "Email: " + Session["email"].ToString();
                Address.Text = "Address: " + Session["address"].ToString();
                City.Text = "City: " + Session["city"].ToString();
                PinCode.Text = "PinCode: " + Session["zip"].ToString();
                State.Text = "State: " + Session["state"].ToString();
            }
        }

        private void FetchProductDetails(string productId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = "SELECT * FROM HairProducts WHERE id = @ProductId";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@ProductId", productId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                lblProductName.Text = reader["name"].ToString();
                lblProductPrice.Text = reader["price"].ToString();
                imgProduct.ImageUrl = reader["image"].ToString();
                totalAmount.Text = reader["price"].ToString();
            }

            reader.Close();
            con.Close();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int quantity = Convert.ToInt32(DropDownList1.SelectedValue);
            int price = Convert.ToInt32(lblProductPrice.Text);
            int total = quantity * price;
            totalAmount.Text = total.ToString();
        }



        protected void confirmBuy_Click(object sender, EventArgs e)
        {
            string productId = Request.QueryString["id"];
            int userId = 0;

            if (Session["id"] != null && int.TryParse(Session["id"].ToString(), out userId))
            {
                int hairProductId = Convert.ToInt32(productId);
                int quantity = Convert.ToInt32(DropDownList1.SelectedValue);
                int price = Convert.ToInt32(lblProductPrice.Text);
                int totalPrice = quantity * price;

                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string query = "INSERT INTO HairProductSales (UserId, HairProductId, Quantity, Price) " +
                               "VALUES (@UserId, @HairProductId, @Quantity, @Price)";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@UserId", userId);
                cmd.Parameters.AddWithValue("@HairProductId", hairProductId);
                cmd.Parameters.AddWithValue("@Quantity", quantity);
                cmd.Parameters.AddWithValue("@Price", totalPrice);


                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Your Order Received Successfully. ')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Failed to place the order. ')</script>");
                }
                con.Close();

            }
            else
            {
                Response.Write("<script>alert('Invalid user session. ')</script>");
            }

        }
    }
}
