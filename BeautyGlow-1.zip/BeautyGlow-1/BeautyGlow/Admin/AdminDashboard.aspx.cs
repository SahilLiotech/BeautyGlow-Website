﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow.Admin
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            countData();
        }

        private void countData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd;

            cmd = new SqlCommand("SELECT COUNT(*) FROM [User]", con);
            int userCount = (int)cmd.ExecuteScalar();
            userCountLabel.Text = userCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM SkinProducts", con);
            int skinProductCount = (int)cmd.ExecuteScalar();
            SkinProducts.Text = skinProductCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM HairProducts", con);
            int hairProductCount = (int)cmd.ExecuteScalar();
            HairProducts.Text = hairProductCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM BodyProducts", con);
            int bodyProductCount = (int)cmd.ExecuteScalar();
            BodyProducts.Text = bodyProductCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM CosmeticProducts", con);
            int cosmeticProductCount = (int)cmd.ExecuteScalar();
            CosmeticProducts.Text = cosmeticProductCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM SkinProductSales", con);
            int skinSalesCount = (int)cmd.ExecuteScalar();
            Skinsales.Text = skinSalesCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM BodyProductSales", con);
            int bodySalesCount = (int)cmd.ExecuteScalar();
            Bodysales.Text = bodySalesCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM HairProductSales", con);
            int hairSalesCount = (int)cmd.ExecuteScalar();
            Hairsales.Text = hairSalesCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM CosmeticSales", con);
            int cosmeticSalesCount = (int)cmd.ExecuteScalar();
            Cosmeticsales.Text = cosmeticSalesCount.ToString();

            cmd = new SqlCommand("SELECT COUNT(*) FROM Feedback", con);
            int feedbackCount = (int)cmd.ExecuteScalar();
            Feedback.Text = feedbackCount.ToString();
        }
    }
}