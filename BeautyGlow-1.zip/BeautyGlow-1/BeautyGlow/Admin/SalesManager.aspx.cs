﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BeautyGlow.Admin
{
    public partial class SalesManager : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            BindSkinProductSalesData();
            BindHairProductSalesData();
            BindBodyProductSalesData();
            BindCosmeticSalesData();
            SkinSalesGrid.Visible = true;
            HairSalesGrid.Visible = false;
            BodySalesGrid.Visible = false;
            CosmeticSalesGrid.Visible = false;
        }

        private void BindSkinProductSalesData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT * FROM SkinProductSales";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            SkinSalesGrid.DataSource = dt;
            SkinSalesGrid.DataBind();
            con.Close();

        }

        private void BindHairProductSalesData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT * FROM HairProductSales";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            HairSalesGrid.DataSource = dt;
            HairSalesGrid.DataBind();
            con.Close();

        }

        private void BindBodyProductSalesData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT * FROM BodyProductSales";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            BodySalesGrid.DataSource = dt;
            BodySalesGrid.DataBind();
            con.Close();

        }

        private void BindCosmeticSalesData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT * FROM CosmeticSales";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CosmeticSalesGrid.DataSource = dt;
            CosmeticSalesGrid.DataBind();
            con.Close();

        }

        protected void skinSales_Click(object sender, EventArgs e)
        {
            SkinSalesGrid.Visible = true;
            HairSalesGrid.Visible = false;
            BodySalesGrid.Visible = false;
            CosmeticSalesGrid.Visible = false;
        }

        protected void hairSales_Click(object sender, EventArgs e)
        {
            HairSalesGrid.Visible = true;
            SkinSalesGrid.Visible = false;
            BodySalesGrid.Visible = false;
            CosmeticSalesGrid.Visible = false;
        }

        protected void bodySales_Click(object sender, EventArgs e)
        {
            BodySalesGrid.Visible = true;
            SkinSalesGrid.Visible = false;
            HairSalesGrid.Visible = false;
            CosmeticSalesGrid.Visible = false;
        }

        protected void cosmeticSales_Click(object sender, EventArgs e)
        {
            CosmeticSalesGrid.Visible = true;
            BodySalesGrid.Visible = false;
            SkinSalesGrid.Visible = false;
            HairSalesGrid.Visible = false;
        }
    }
}