﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow.Admin
{
    public partial class UserManager : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            BindUserData();
        }
        private void BindUserData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            string query = "SELECT * FROM [User]";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;

            Label lblId = (Label)row.FindControl("IdLabel");

            Uid.Text = lblId.Text;
        }

        protected void deleteBtn_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM [User] Where Id=@uid";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@uid", Uid.Text);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Response.Write("<script>alert('Record Deleted Successfully')</script>");
                BindUserData();
                Uid.Text = "";
            }
            else
            {
                Response.Write("<script>alert('Error While Deleting the record')</script>");
            }

            con.Close();
        }
    }
}