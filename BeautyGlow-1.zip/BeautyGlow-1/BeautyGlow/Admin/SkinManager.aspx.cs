﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Web.UI.WebControls;

namespace BeautyGlow.Admin
{
    public partial class SkinManager : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            showData();
        }

        private void showData()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM SkinProducts", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string name = inputProductName.Text;
            string price = inputProductPrice.Text;
            string about_item = inputAboutItem.Text;
            string description = inputDescription.Text;
            string imageName = Path.GetFileName(fileUploadProductImage.FileName);
            string imagePath = Path.Combine(Server.MapPath("~/images/SkinProduct/"), imageName);
            fileUploadProductImage.SaveAs(imagePath);
            string query = "INSERT INTO SkinProducts (name,image,price,about_item,description) VALUES (@name,@image,@price,@about_item,@description)";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@image", "~/images/SkinProduct/" + imageName);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@about_item", about_item);
            cmd.Parameters.AddWithValue("@description", description);

            int k = cmd.ExecuteNonQuery();

            if (k > 0)
            {
                Response.Write("<script> alert('Record inserted Successfully')</script>");
                clearData();
                showData();
            }
            else
            {
                Response.Write("<script> alert('Record Not inserted')</script>");
            }

            con.Close();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                string imageName = Path.GetFileName(fileUploadProductImage.FileName);
                string imagePath = Path.Combine(Server.MapPath("~/images/SkinProduct/"), imageName);
                fileUploadProductImage.SaveAs(imagePath);
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                string query = "UPDATE SkinProducts SET name=@name, image=@image, price=@price, about_item=@about_item, description=@description, created_at=GETDATE() WHERE Id=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", inputProductName.Text);
                cmd.Parameters.AddWithValue("@image", "~/images/SkinProduct/" + imageName);
                cmd.Parameters.AddWithValue("@price", inputProductPrice.Text);
                cmd.Parameters.AddWithValue("@about_item", inputAboutItem.Text);
                cmd.Parameters.AddWithValue("@description", inputDescription.Text);
                cmd.Parameters.AddWithValue("@id", inputProductId.Text);


                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Record Updated Successfully')</script>");
                    clearData();
                    showData();
                }
                else
                {
                    Response.Write("<script>alert('No records updated. Check the ID.')</script>");
                }
                con.Close();

            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string deleteQuery = "DELETE FROM SkinProducts WHERE Id=@pid";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmdDelete = new SqlCommand(deleteQuery, con);
            cmdDelete.Parameters.AddWithValue("@pid", inputProductId.Text);
            int rowsAffected = cmdDelete.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Response.Write("<script>alert('Record Deleted Successfully')</script>");
                clearData();
                showData();
            }
            else
            {
                Response.Write("<script>alert('No records deleted. Check the ID.')</script>");
            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            clearData();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;

            Label lblId = (Label)row.FindControl("label9");
            Label lblProductName = (Label)row.FindControl("label10");
            System.Web.UI.WebControls.Image img = (System.Web.UI.WebControls.Image)row.FindControl("label11");
            Label lblPrice = (Label)row.FindControl("label12");
            Label lblAboutItem = (Label)row.FindControl("label13");
            Label lblDescription = (Label)row.FindControl("label14");
            Label lblCreatedAt = (Label)row.FindControl("label15");


            inputProductId.Text = ((Label)row.FindControl("label9")).Text;
            inputProductName.Text = ((Label)row.FindControl("label10")).Text;
            Image.ImageUrl = img.ImageUrl;
            Image.Visible = true;
            fileUploadProductImage.Attributes["value"] = img.ImageUrl;
            inputProductPrice.Text = ((Label)row.FindControl("label12")).Text;
            inputAboutItem.Text = ((Label)row.FindControl("label13")).Text;
            inputDescription.Text = ((Label)row.FindControl("label14")).Text;

        }

        private void clearData()
        {
            inputProductId.Text = "";
            inputProductName.Text = "";
            inputProductPrice.Text = "";
            inputAboutItem.Text = "";
            inputDescription.Text = "";
            Image.ImageUrl = "";
            Image.Visible = false;
        }

        private bool ValidateFields()
        {
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(inputProductId.Text))
            {
                errorId.Visible = true;
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(inputProductName.Text))
            {
                errorName.Visible = true;
                isValid = false;
            }
            else
            {
                errorName.Visible = false;
            }

            if (!fileUploadProductImage.HasFile)
            {
                errorFile.Visible = true;
                isValid = false;
            }
            else
            {
                errorFile.Visible = false;
            }


            if (string.IsNullOrWhiteSpace(inputProductPrice.Text))
            {
                errorProduct.Visible = true;
                isValid = false;
            }
            else
            {
                errorProduct.Visible = false;
            }


            if (string.IsNullOrWhiteSpace(inputAboutItem.Text))
            {
                errorAbout.Visible = true;
                isValid = false;
            }
            else
            {
                errorAbout.Visible = false;
            }


            if (string.IsNullOrWhiteSpace(inputDescription.Text))
            {
                errorDescription.Visible = true;
                isValid = false;
            }
            else
            {
                errorDescription.Visible = false;
            }

            return isValid;
        }
    }
}