﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BeautyGlow.Admin
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] != null)
            {
                logout.Visible = true;
                userProfile.Visible = true;
                if (Session["fname"] != null)
                {
                    userProfile.Text = Session["fname"].ToString().ToUpper();
                }
            }
        }
    }
}