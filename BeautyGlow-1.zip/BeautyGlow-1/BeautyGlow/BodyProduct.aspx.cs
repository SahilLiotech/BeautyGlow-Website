﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class BodyProduct : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {


                if (Request.QueryString["id"] != null)
                {
                    string productId = Request.QueryString["id"];
                    FetchBodyProductDetails(productId);
                }
            }
        }
        private void FetchBodyProductDetails(string productId)
        {
            SqlConnection con = new SqlConnection(connectionString);
            string query = "SELECT * FROM BodyProducts WHERE id = @ProductId";
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@ProductId", productId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                lblProductName.Text = reader["name"].ToString();
                lblProductPrice.Text = reader["price"].ToString();
                lblProductDescription.Text = reader["description"].ToString();
                ProductImage.ImageUrl = reader["image"].ToString();
                if (!reader.IsDBNull(reader.GetOrdinal("about_item")))
                {
                    string aboutItem = reader["about_item"].ToString().Trim();
                    string[] aboutItemArray = aboutItem.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);

                    lblProductAboutItem.Text = "<ul>";
                    foreach (string item in aboutItemArray)
                    {
                        string trimmedItem = item.Trim();
                        if (!string.IsNullOrWhiteSpace(trimmedItem))
                        {
                            lblProductAboutItem.Text += "<li>" + trimmedItem + "</li>";
                        }
                    }
                    lblProductAboutItem.Text += "</ul>";
                }
                else
                {
                    lblProductAboutItem.Text = "No information available";
                }

            }

            reader.Close();
            con.Close();
        }

        protected void buyButton_Click(object sender, EventArgs e)
        {
            if (Session["email"] != null)
            {
                if (Request.QueryString["id"] != null)
                {
                    string productId = Request.QueryString["id"];
                    Response.Redirect("BuyBodyProduct.aspx?id=" + productId);
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}