﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Cart : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCart();
            }
        }

        protected void BindCart()
        {
            List<CartItem> cartItems = Session["CartItems"] as List<CartItem>;

            if (cartItems != null && cartItems.Count > 0)
            {
                CartRepeater.DataSource = cartItems;
                CartRepeater.DataBind();

                int totalAmountValue = cartItems.Sum(item => item.ProductPrice);
                totalAmount.Text = totalAmountValue.ToString();
            }
            else
            {
                emptyCartImage.Visible = true;
                confirmBuy.Visible = false;
                totalAmountTxt.Visible = false;
                totalAmount.Visible = false;
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddl = (DropDownList)sender;
            RepeaterItem item = (RepeaterItem)ddl.NamingContainer;
            Label lblProductPrice = (Label)item.FindControl("lblProductPrice");
            Label totalAmt = (Label)item.FindControl("subTotal");

            int quantity = Convert.ToInt32(ddl.SelectedValue);
            int price = Convert.ToInt32(lblProductPrice.Text);
            int total = quantity * price;
            totalAmt.Text = total.ToString();

            RecalculateTotalAmount();
        }

        protected void removeBtn_Click(object sender, EventArgs e)
        {
            LinkButton removeButton = (LinkButton)sender;
            int itemIndex = Convert.ToInt32(removeButton.CommandArgument);

            List<CartItem> cart = (List<CartItem>)Session["CartItems"];

            if (cart != null && itemIndex >= 0 && itemIndex < cart.Count)
            {
                cart.RemoveAt(itemIndex);

                Session["CartItems"] = cart;

                RecalculateTotalAmount();

                Response.Redirect(Request.RawUrl);
            }
        }
        public void RecalculateTotalAmount()
        {
            int totalAmountValue = 0;
            foreach (RepeaterItem item in CartRepeater.Items)
            {
                Label lblSubTotal = (Label)item.FindControl("subTotal");

                int subTotal = Convert.ToInt32(lblSubTotal.Text);

                totalAmountValue += subTotal;
            }

            totalAmount.Text = totalAmountValue.ToString();
        }


        protected void confirmBuy_Click(object sender, EventArgs e)
        {
            if (Session["email"] == null)
            {
                Response.Redirect("~/Login.aspx");
            }
            else
            {
                List<CartItem> cartItems = Session["CartItems"] as List<CartItem>;

                if (cartItems != null && cartItems.Count > 0)
                {
                    foreach (RepeaterItem repeaterItem in CartRepeater.Items)
                    {
                        DropDownList ddlQuantity = (DropDownList)repeaterItem.FindControl("DropDownList1");
                        Label lblSubTotal = (Label)repeaterItem.FindControl("subTotal");
                        int price = Convert.ToInt32(lblSubTotal.Text);
                        int selectedQuantity = GetSelectedQuantity(ddlQuantity);
                        int itemIndex = repeaterItem.ItemIndex;
                        CartItem item = cartItems[itemIndex];


                        switch (item.ProductType)
                        {
                            case "SkinCare":
                                InsertIntoSkinCareTable(item, selectedQuantity, price);
                                break;
                            case "HairCare":
                                InsertIntoHairCareTable(item, selectedQuantity, price);
                                break;
                            case "BodyCare":
                                InsertIntoBodyCareTable(item, selectedQuantity, price);
                                break;
                            case "Cosmetic":
                                InsertIntoCosmeticTable(item, selectedQuantity, price);
                                break;
                            default:
                                break;
                        }
                    }

                    Session["CartItems"] = new List<CartItem>();
                    BindCart();
                    ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Your Order received successfully!');setTimeout(function(){ window.location.href = 'cart.aspx'; }, 1000);", true);
                }

            }
        }


        protected void InsertIntoSkinCareTable(CartItem item, int quantity, int price)
        {
            int userId = Convert.ToInt32(Session["id"]);
            int productId = GetProductIdByName(item.ProductName, "SkinProducts");
            string query = @"INSERT INTO SkinProductSales (UserId, SkinProductId, Quantity, Price)
                   VALUES (@UserId, @SkinProductId, @Quantity, @Price)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@SkinProductId", productId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        protected void InsertIntoBodyCareTable(CartItem item, int quantity, int price)
        {
            int userId = Convert.ToInt32(Session["id"]);
            int productId = GetProductIdByName(item.ProductName, "BodyProducts");
            string query = @"INSERT INTO BodyProductSales (UserId, BodyProductId, Quantity, Price)
                   VALUES (@UserId, @SkinProductId, @Quantity, @Price)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@SkinProductId", productId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        protected void InsertIntoHairCareTable(CartItem item, int quantity, int price)
        {
            int userId = Convert.ToInt32(Session["id"]);
            int productId = GetProductIdByName(item.ProductName, "HairProducts");
            string query = @"INSERT INTO HairProductSales (UserId, HairProductId, Quantity, Price)
                   VALUES (@UserId, @SkinProductId, @Quantity, @Price)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@SkinProductId", productId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        protected void InsertIntoCosmeticTable(CartItem item, int quantity, int price)
        {
            int userId = Convert.ToInt32(Session["id"]);
            int productId = GetProductIdByName(item.ProductName, "CosmeticProducts");
            string query = @"INSERT INTO CosmeticSales (UserId, CosmeticId, Quantity, Price)
                   VALUES (@UserId, @SkinProductId, @Quantity, @Price)";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@SkinProductId", productId);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.ExecuteNonQuery();
                }
            }
        }



        protected int GetProductIdByName(string productName, string tableName)
        {
            int productId = 0;
            string query = @"SELECT Id FROM " + tableName + " WHERE name = @ProductName";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@ProductName", productName);
                    productId = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }

            return productId;
        }

        protected int GetSelectedQuantity(DropDownList ddl)
        {
            if (ddl != null && ddl.SelectedIndex >= 0)
            {
                return Convert.ToInt32(ddl.SelectedValue);
            }
            return 0;
        }


    }
}
