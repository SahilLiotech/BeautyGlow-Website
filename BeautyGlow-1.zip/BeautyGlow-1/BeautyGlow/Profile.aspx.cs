﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Detail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] != null)
            {
                string fname = Session["fname"].ToString().ToUpper();
                string lname = Session["lname"].ToString().ToUpper();
                string email = Session["email"].ToString();
                string address = Session["address"].ToString().ToUpper();
                string city = Session["city"].ToString().ToUpper();
                string zip = Session["zip"].ToString();
                string state = Session["state"].ToString().ToUpper();

                lblFirstName.Text = fname;
                lblLastName.Text = lname;
                lblEmail.Text = email;
                lblAddress.Text = address;
                lblCity.Text = city;
                lblZip.Text = zip;
                lblState.Text = state;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void backBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}