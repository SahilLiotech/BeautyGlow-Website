﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Contact : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string email = txtEmail.Text;
            string feedback = txtFeedback.Text;
            string query = "INSERT INTO Feedback (name,email,feedback) VALUES (@name,@email,@feedback)";

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@feedback", feedback);

            int result = cmd.ExecuteNonQuery();

            if (result > 0)
            {
                Response.Write("<script>alert('Thank For Submit Your Feedback(QUERY)......')</script>");
                txtName.Text = null;
                txtEmail.Text = null;
                txtFeedback.Text = null;
            }
            con.Close();
        }
    }
}