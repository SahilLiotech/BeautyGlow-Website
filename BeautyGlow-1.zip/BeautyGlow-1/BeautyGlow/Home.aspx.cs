﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class Home : System.Web.UI.Page
    {

        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            SkinCareProducts();
            HairCareProducts();
            BodyCareProducts();
            CosmeticProducts();
        }
        protected void SkinCareProducts()
        {
            string query ="SELECT TOP 4 * FROM SkinProducts ORDER BY NEWID()";

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand command = new SqlCommand(query, con);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            rptSkinCareProducts.DataSource = dataTable;
            rptSkinCareProducts.DataBind();

            con.Close();
       }

        protected void HairCareProducts()
        {
            string query = "SELECT TOP 4 * FROM HairProducts ORDER BY NEWID()";

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand command = new SqlCommand(query, con);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            rptHairCareProducts.DataSource = dataTable;
            rptHairCareProducts.DataBind();

            con.Close();
        }

        protected void BodyCareProducts()
        {
            string query = "SELECT TOP 4 * FROM BodyProducts ORDER BY NEWID()";

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand command = new SqlCommand(query, con);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            rptBodyCareProducts.DataSource = dataTable;
            rptBodyCareProducts.DataBind();

            con.Close();
        }

        protected void CosmeticProducts()
        {
            string query = "SELECT TOP 4 * FROM CosmeticProducts ORDER BY NEWID()";

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand command = new SqlCommand(query, con);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            rptMakeUpProducts.DataSource = dataTable;
            rptMakeUpProducts.DataBind();

            con.Close();
        }
   }
}