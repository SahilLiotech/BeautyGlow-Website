﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BeautyGlow
{
    public partial class cosmetic : System.Web.UI.Page
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BeautyGlowConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            CosmeticProducts();
        }
        protected void CosmeticProducts()
        {
            string query = "SELECT * FROM CosmeticProducts";

            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand command = new SqlCommand(query, con);

            SqlDataAdapter adapter = new SqlDataAdapter(command);

            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            rptMakeUpProducts.DataSource = dataTable;
            rptMakeUpProducts.DataBind();

            con.Close();
        }
    }
}